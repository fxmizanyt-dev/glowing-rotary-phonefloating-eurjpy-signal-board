# EUR/USD Quotex Signal Board v2

Android floating display-only signal board for EUR/USD 1-minute candles.

Features:
- Live EURUSD 1-minute OHLC data from BiQuote public API (no API key for read endpoints).
- EMA 9 and EMA 21.
- RSI 14.
- Simple CALL / PUT / WAIT rules.
- Floating overlay suitable for viewing over another app such as Quotex.
- Voice alert when CALL or PUT changes.
- No auto-clicking, no auto-trading.

Important: market-data feeds can differ from Quotex's own feed. Signals are indicator-based and are not guaranteed to win.
