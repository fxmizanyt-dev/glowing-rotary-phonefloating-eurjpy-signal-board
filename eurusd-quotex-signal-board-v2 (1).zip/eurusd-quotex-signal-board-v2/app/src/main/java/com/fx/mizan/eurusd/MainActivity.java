package com.fx.mizan.eurusd;

import android.app.Activity;
import android.content.Intent;
import android.net.Uri;
import android.os.Bundle;
import android.provider.Settings;
import android.widget.Button;
import android.widget.LinearLayout;
import android.widget.TextView;
import android.graphics.Color;
import android.view.Gravity;

public class MainActivity extends Activity {
    @Override public void onCreate(Bundle b) {
        super.onCreate(b);
        LinearLayout box = new LinearLayout(this); box.setOrientation(LinearLayout.VERTICAL); box.setPadding(36,48,36,36); box.setGravity(Gravity.CENTER);
        TextView title = new TextView(this); title.setText("EUR/USD • 1M\nQuotex Signal Board v2"); title.setTextSize(24); title.setTextColor(Color.BLACK); title.setGravity(Gravity.CENTER); box.addView(title);
        TextView info = new TextView(this); info.setText("Live price + EMA9/EMA21 + RSI + voice alerts\nDisplay-only • no auto trading"); info.setTextSize(16); info.setGravity(Gravity.CENTER); box.addView(info);
        Button start = new Button(this); start.setText("Start Floating Signal Board"); box.addView(start);
        start.setOnClickListener(v -> startBoard()); setContentView(box);
    }
    private void startBoard() {
        if (!Settings.canDrawOverlays(this)) { startActivity(new Intent(Settings.ACTION_MANAGE_OVERLAY_PERMISSION, Uri.parse("package:"+getPackageName()))); return; }
        Intent i = new Intent(this, FloatingService.class); if (android.os.Build.VERSION.SDK_INT >= 26) startForegroundService(i); else startService(i);
    }
    @Override protected void onResume() { super.onResume(); }
}
